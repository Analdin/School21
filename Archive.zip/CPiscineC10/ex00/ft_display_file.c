/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_display_file.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hspengle <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/28 09:56:24 by hspengle          #+#    #+#             */
/*   Updated: 2020/09/30 11:05:55 by hspengle         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>

void	showfile(char *filename)
{
	int myfile;
	char character;

	myfile = open(filename, O_RDWR);
	if (myfile < 0)
	{
		return ;
	}
	while (read(myfile, &character, 1))
	{
		write(1, &character, 1);
	}
	close(myfile);
}

int	main(int argc, char *argv[])
{
	if(argc == 1)
	{
		write(2, "File name missing.\n", 16);
	}
	else if (argc > 2)
	{
		write(2, "Too many arguments.\n", 17);
	}
	else if (argc <= 01)
	{
		write(2, "Cannot read file.\n", 15);
	}
	else
	{
		showfile(argv[1]);
	}
	return (0);
}
