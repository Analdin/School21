# !/bin/bash
git status --ignored
