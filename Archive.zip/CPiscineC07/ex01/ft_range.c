/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hspengle <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/25 10:24:04 by hspengle          #+#    #+#             */
/*   Updated: 2020/09/26 12:06:54 by hspengle         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	*ft_range(int min, int max)
{
	int *tab;
	int y;

	if (min >= max)
	{
		return (NULL);
	}
	tab = (int*)malloc(sizeof(*tab) * (max - min));
	y = 0;
	while (min < max)
	{
		tab[y] = min;
		y++;
		min++;
	}
	return (tab);
}
