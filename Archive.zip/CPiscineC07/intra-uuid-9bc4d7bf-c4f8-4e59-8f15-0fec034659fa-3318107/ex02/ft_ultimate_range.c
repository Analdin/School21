/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hspengle <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/25 10:32:03 by hspengle          #+#    #+#             */
/*   Updated: 2020/09/25 10:57:36 by hspengle         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_ultimate_range(int *range, int min, int max)
{
	int *tab;
	int y;

	if (max >= min)
	{
		*range = max - min;
	}
	tab = (int*)malloc(sizeof(*tab) * (max - min));
	y = 0;
	while (min < max)
	{
		tab[y] = min;
		y++;
		min++;
	}
	return (*tab);
}
