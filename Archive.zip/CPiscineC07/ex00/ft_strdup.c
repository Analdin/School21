/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hspengle <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/25 10:13:05 by hspengle          #+#    #+#             */
/*   Updated: 2020/09/26 12:05:35 by hspengle         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int	main(void)
{
	char str[11];
	char *istr;

	str[11] = "0123456789";
	istr = strdup(str);
	printf("Дубликат - %s\n", istr);
	free(istr);
	return (0);
}
