/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hspengle <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/20 13:58:29 by hspengle          #+#    #+#             */
/*   Updated: 2020/09/20 14:55:21 by hspengle         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

char *ft_strncat(char *dest, char *src, unsigned int nb){
	
	unsigned int n, b;

	n = 0;
	b  = 0;	
	
	while (dest[n] != '\0') n++;

	while (src[b] != '\0' && b < nb) {
		dest[n] = src[b];
		n++;
		b++;
	}
	
	dest[n] = '\0';
	return (dest);

}

int main(void){
	return 0;
}
