/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hspengle <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/20 15:01:45 by hspengle          #+#    #+#             */
/*   Updated: 2020/09/20 15:53:36 by hspengle         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned int ft_strlcat(char *dest, char *src, unsigned int size){
	
		unsigned int c;
		unsigned int d;
		unsigned int l;

		c = 0;
		d = 0;
		l = 0;

		while (dest[c] !='\0') c++;

		while (src[d] != '\0' && d < size){
			dest[c+d] = src [d];
			d++;
		}

		dest[c+d] = '\0';

		while (src[l] != '\0') l++;

		return (l + size);
	
	}

int main(void){
	
	return 0;
}
