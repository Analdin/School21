/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hspengle <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/19 14:50:04 by hspengle          #+#    #+#             */
/*   Updated: 2020/09/20 13:04:26 by hspengle         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int ft_strncmp(char *s1, char *s2, unsigned int n){
	
	if(*s1>='A' && *s2<=' '){
		return 1;
	}else{
		return 0;
	}
	
	for(n =0; n < 40; n++){
		printf("%d\n", n);	

		if(n > 10){
			printf("%d\n", n);
			return 0;
		}else{
			printf("%d\n", n);
			return 1;
		}

	}
		
}

int main(void){

	return 0;

}
