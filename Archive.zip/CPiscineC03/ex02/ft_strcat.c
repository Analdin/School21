/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcat2.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hspengle <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/20 13:52:29 by hspengle          #+#    #+#             */
/*   Updated: 2020/09/20 13:57:42 by hspengle         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char *ft_strcat(char *dest, char *src){
	
	int a;
	int b;

	a=0;
	b=0;

	while(dest[a] !='\0') a++;
	
	while(src[b] !='\0') {
		dest[a+b] = src[b];
		b++;
	}	
	
	dest[a+b] = '\0';
	return (dest);
}

int main(void){

	return 0;
}
