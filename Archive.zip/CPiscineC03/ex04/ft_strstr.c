/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hspengle <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/20 14:47:15 by hspengle          #+#    #+#             */
/*   Updated: 2020/09/20 14:57:33 by hspengle         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char *ft_strstr(char *str, char *to_find){
	
	int x;
	int y;

	x=0;
	y=0;

	while (str[x] != '\0') x++;

	while (to_find[y] != '\0') {
		str[x] = to_find[y];
		x++;
		y++;
	}

	str[y] = '\0';
	return (str);

}

int main(void){
	return 0;
}
