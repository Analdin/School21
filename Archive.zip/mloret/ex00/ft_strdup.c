/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mlorette <mlorette@student.21-schoo>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/24 12:58:58 by mlorette          #+#    #+#             */
/*   Updated: 2020/09/25 21:35:54 by mlorette         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

char	*ft_strdup(char *src)
{
	int		i;
	char	*dest;

	i = 0;
	while (*(src + i) != 0)
		i++;
	dest = (char *)malloc(i);
	if (i == 0)
		return ("\0");
	i = 0;
	while (*(src + i) != 0)
	{
		*(dest + i) = *(src + i);
		i++;
	}
	if (dest != 0)
		return (dest);
	else
		return (0);
}

int main(void)
{
    char *res;
    res = ft_strdup("abcdefgth");
    printf("%s", res);
    return (0);
}
