/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mlorette <mlorette@student.21-schoo>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/24 19:43:48 by mlorette          #+#    #+#             */
/*   Updated: 2020/09/25 21:32:11 by mlorette         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_ultimate_range(int **range, int min, int max)
{
	int z;
	int *mas;

	z = 0;
	if ((min >= max) || ((max - min) * 4) > 16711568)
		return (0);
	else
	{
		mas = (int *)malloc((max - min) * 4);
		while (z < (max - min))
		{
			mas[z] = min + z;
			z++;
		}
		range = &mas;
		return (z);
	}
}

int main(void)
{
    int res;
    int i;
    
    i = 2;
    res = ft_ultimate_range(
}
