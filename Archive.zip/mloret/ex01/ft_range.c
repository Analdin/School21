/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mlorette <mlorette@student.21-schoo>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/24 17:23:16 by mlorette          #+#    #+#             */
/*   Updated: 2020/09/25 21:00:55 by mlorette         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

int	*ft_range(int min, int max)
{
	int	*l;
	int	z;

	z = 0;
	if ((min >= max) || ((max - min) * 4) > 16711568)
		return (NULL);
	else
	{
		l = (int *)malloc((max - min) * 4);
		while (z < max - min)
		{
			l[z] = min + z;
			z++;
		}
		return (l);
	}
}

int main(void)
{
    int i;
    int *res;
    
    i = 2;
    res = ft_range(2,10);
    while (i < 10)
    {
        printf("%d", res[i]);
        i++;
    }
    return (0);
}
