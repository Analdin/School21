/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_count_if.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hspengle <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/30 12:51:38 by hspengle          #+#    #+#             */
/*   Updated: 2020/09/30 15:13:11 by hspengle         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_count_if(char **tab, int length, int (*f)(char*))
{
	int x;
	int counter;

	x = 0;
	counter = 0;
	while (tab[x])
	{
		counter++;
		x++;
	}
	return (counter);
}
