/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_map.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hspengle <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/30 11:41:44 by hspengle          #+#    #+#             */
/*   Updated: 2020/09/30 15:12:55 by hspengle         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

int	*ft_map(int *tab, int length, int (*f)(int))
{
	int x;
	int *e_tab;

	x = 0;
	e_tab = (int*)malloc(sizeof(int) * length);
	while (x < length)
	{
		e_tab[x] = f(tab[x]);
		x++;
	}
	return (e_tab);
}
