/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_string_tab.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hspengle <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/30 15:48:41 by hspengle          #+#    #+#             */
/*   Updated: 2020/09/30 15:55:02 by hspengle         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_strcmp(char *s1, char *s2)
{
	int	x;

	x = 0;
	while (s1[x])
	{
		if (s1[x] != s2[x])
		{
			return (s1[x] - s2[x]);
		}
		x++;
	}
	if (s2[x] == '\0')
		return (0);
	else
		return (-s2[x]);
}

void	ft_sort_string_tab(char **tab)
{
	int		x;
	int		y;
	char	*templ;

	x = 0;
	while (tab[x] != 0)
	{
		y = x;
		while (tab[y] != 0)
		{
			if (ft_strcmp(tab[x], tab[y]) > 0)
			{
				templ = tab[x];
				tab[x] = tab[y];
				tab[y] = templ;
			}
			y++;
		}
		x++;
	}
}
