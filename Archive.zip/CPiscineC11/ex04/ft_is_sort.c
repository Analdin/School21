/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_sort.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hspengle <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/30 12:57:22 by hspengle          #+#    #+#             */
/*   Updated: 2020/09/30 15:21:48 by hspengle         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>

int	ft_is_sort(int *tab, int length, int (*f)(int, int))
{
	int x;

	x = 0;
	while (x < length - 1)
	{
		if (f(tab[x], tab[x + 1]) >= 0)
		{
			x++;
		}
		else
		{
			x = length + 1;
		}
	}
	if (x == length - 1)
	{
		return (1);
	}
	while (x < length - 1)
	{
		if (f(tab[x], tab[x + 1]) <= 0)
		{
			x++;
		}
		else
		{
			x = length + 1;
		}
	}
	if (x == length - 1)
	{
		return (1);
	}
	return (0);
}
