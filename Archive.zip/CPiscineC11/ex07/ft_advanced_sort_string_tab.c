/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_advanced_sort_string_tab.c                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hspengle <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/30 15:23:46 by hspengle          #+#    #+#             */
/*   Updated: 2020/09/30 15:48:11 by hspengle         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_advanced_sort_string_tab(char **tab, int (*cmp) (char *, char *))
{
	int x;
	int order;
	char *tmpvid;

	order = 0;
	while (!order)
	{
		x = 0;
		order = 1;
		while (tab[++x])
		{
			if (cmp(tab[x - 1], tab[x]) > 0)
			{
				tmpvid = tab[x - 1];
				tab[x - 1] = tab[x];
				tab[x] = tmpvid;
				order = 0;
			}
		}
	}
}
