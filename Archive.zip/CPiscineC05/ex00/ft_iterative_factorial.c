/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hspengle <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/23 12:49:40 by hspengle          #+#    #+#             */
/*   Updated: 2020/09/23 14:59:57 by hspengle         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int		ft_iterative_factorial(int nb)
{
	int x;
	int res;

	x = 5;
	if ((nb <= 0) || nb > 20)
	{
		return (0);
	}
	if (x == 1)
	{
		return (1);
	}
	while (x <= nb)
	{
		res = x * res;
	}
	return (res);
}

int		main(void)
{
	int nb;

	nb = 5;
	printf("%d", ft_iterative_factorial(nb));
	return (0);
}
