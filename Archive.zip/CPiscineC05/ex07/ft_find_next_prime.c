/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_find_next_prime.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hspengle <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/23 14:54:59 by hspengle          #+#    #+#             */
/*   Updated: 2020/09/23 15:42:22 by hspengle         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdbool.h>

int		ft_is_prime(int nb)
{
	int	x;

	x = 2;
	if (nb <= 1)
		return (0);
	while (x <= nb / x)
	{
		if (nb % x == 0)
			return (0);
		x++;
	}
	return (1);
}

int		ft_find_next_prime(int nb)
{
	int	x;

	if (nb < 2)
		nb = 2;
	x = nb;
	while (x < 2 * nb)
	{
		if (ft_is_prime(x))
			return (x);
		x++;
	}
	return (0);
}

int		main(void)
{
	int res;

	res = 5;
	printf("%d", ft_find_next_prime(res));
	return (0);
}
