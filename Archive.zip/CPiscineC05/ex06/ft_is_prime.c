/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_prime.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hspengle <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/23 14:52:03 by hspengle          #+#    #+#             */
/*   Updated: 2020/09/23 15:39:48 by hspengle         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdbool.h>

int		ft_is_prime(int nb)
{
	int i;

	if (nb > 1)
	{
		for (i = 2; i < nb; i++)
		{
			if (nb / i == 0)
			{
				return (false);
			}
		}
		return (true);
	}
	else
	{
		return (false);
	}
}

int		main(void)
{
	int res;

	res = 5;
	printf("%d", ft_is_prime(res));
	return (0);
}
