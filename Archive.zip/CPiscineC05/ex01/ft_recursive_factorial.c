/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putchar.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hspengle <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/23 14:20:32 by hspengle          #+#    #+#             */
/*   Updated: 2020/09/23 15:01:07 by hspengle         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int		ft_recursive_factorial(int nb)
{
	if (nb == 0 || nb == 1)
	{
		return (1);
	}
	return (nb * ft_recursive_factorial(nb - 1));
}

int		main(void)
{
	int y;

	printf("Результат - n!\nInput n: ");
	y = 10;
	if (y >= 0)
	{
		printf("%d! = %d\n", y, ft_recursive_factorial(y));
	}
	else
	{
		printf("Ошибка, x должен быть >= 0\n");
	}
	return (0);
}
