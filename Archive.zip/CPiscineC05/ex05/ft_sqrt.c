/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sqrt.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hspengle <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/23 14:46:14 by hspengle          #+#    #+#             */
/*   Updated: 2020/09/23 15:37:28 by hspengle         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int		ft_sqrt(int nb)
{
	int x;
	int y;

	x = 1;
	y = 1;
	if (nb == 0)
	{
		return (0);
	}
	while (x * x < nb)
	{
		x++;
	}
	if ((nb % 1) == 0)
	{
		return (1);
	}
	else
	{
		return (0);
	}
}

int		main(void)
{
	int res;

	res = 5;
	printf("%d", ft_sqrt(res));
	return (0);
}
