/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_create_elem.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hspengle <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/10/01 09:46:23 by hspengle          #+#    #+#             */
/*   Updated: 2020/10/01 11:50:24 by hspengle         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "includes/ft_list.h"

t_list	*ft_create_elem(void *data)
{
	t_list *tmp;
	if (data == NULL)
	{
		exit(-1);
	}
	if (!(tmp = malloc(sizeof(t_list))))
	{
		return (NULL);
	}
	tmp->data = data;
	tmp->next = NULL;
	return (tmp);
}
