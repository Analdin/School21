/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_last.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hspengle <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/10/01 13:25:37 by hspengle          #+#    #+#             */
/*   Updated: 2020/10/01 13:58:58 by hspengle         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "includes/ft_list.h"

void	ft_list_push_back(t_list **begin_list, void *data)
{
	t_list *row;

	row = ft_create_elem(data);
	row->next = *begin_list;
	*begin_list = row;
}

t_list	*ft_list_push_paramsk(int ac, char **av)
{
	t_list	*nowlist;
	int		x;

	nowlist = 0;
	x = 1;
	while (x < ac)
		ft_list_push_front(&nowlist, av[i++]);
	return (nowlist);
}
