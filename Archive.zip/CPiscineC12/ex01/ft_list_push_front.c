/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_push_front.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hspengle <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/10/01 11:15:50 by hspengle          #+#    #+#             */
/*   Updated: 2020/10/01 12:13:54 by hspengle         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <unistd.h>
#include "includes/ft_list.h"

void	ft_list_push_front(t_list **begin_list, void *data)
{
	t_list *elm;
	elm = ft_create_elem(data);
	elm->next = *begin_list;
	*begin_list = elm;
}
