/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: twilford <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/25 21:42:29 by twilford          #+#    #+#             */
/*   Updated: 2020/09/25 23:13:51 by twilford         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

int	ft_ultimate_range(int **range, int min, int max)
{
	long int	size;
	int			*arr;
	long int	i;

	size = (long int)max - (long int)min;
	i = 0;
	if (size <= 0)
		return (0);
	if (size > 2147483647)
		return (-1);
	if (malloc(4 * size) == NULL)
		return (-1);
	arr = malloc(4 * size);
	while (i < (size))
	{
		arr[i] = min + i;
		i++;
	}
	*range = arr;
	return (size);
}

int main(void)
{
    int i;
    int **res;
    
    i = ft_ultimate_range(&res, 2, 15);
    printf("%d", i);
    return (0);
}
