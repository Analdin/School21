/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: twilford <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/25 00:26:38 by twilford          #+#    #+#             */
/*   Updated: 2020/09/25 21:36:19 by twilford         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

char	*ft_strcpy(char *dest, char *src)
{
	int i;

	i = 0;
	while (*(src + i))
	{
		dest[i] = *(src + i);
		i++;
	}
	dest[i] = *(src + i);
	return (dest);
}

char	*ft_strdup(char *src)
{
	int		size;
	char	*ptr;

	ptr = src;
	while (*src)
		src++;
	size = src - ptr;
	src = ptr;
	ptr = ft_strcpy(malloc(size), src);
	return (ptr);
}

int main(void)
{
    char *res;
    res = ft_strdup("abcdefght");
    printf("%s", res);
    return (0);
}
