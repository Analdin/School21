/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: twilford <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/25 12:15:22 by twilford          #+#    #+#             */
/*   Updated: 2020/09/25 23:14:40 by twilford         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

int	*ft_range(int min, int max)
{
	long int	size;
	int			*arr;
	long int	i;

	size = (long int)max - (long int)min;
	i = 0;
	if (size <= 0)
		return (NULL);
	arr = malloc(4 * size);
	while (i < (size))
	{
		arr[i] = min + i;
		i++;
	}
	return (arr);
}

int main(void)
{
    int i;
    int *res;
    
    i = 0;
    res = ft_range(5, 15);
    while (i < 15-5)
    {
        printf("%d", res[i]);
        i++;
    }
    return (0);
}
