/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: twilford <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/25 23:27:00 by twilford          #+#    #+#             */
/*   Updated: 2020/09/25 23:27:09 by twilford         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int		len_(int size, char **strs)
{
	int len;
	int i;
	int j;
	
	i = 0;
	j = 0;
	len = 0;
	while (i < size)
	{
		while (strs[i][j])
		{
			len++;
			j++;
		}
		j = 0;
		i++;
	}
    return (len);
}

int		ft_strlen(char *str)
{
	char *ptr;

	ptr = str;
	while (*str)
		str++;
	return (str - ptr);
}

char	*ft_strjoin(int size, char **strs, char *sep)
{
    int i;
    int j;
	char	*ptr;
	int		len;
	int		len_s;
    
    i = 0;
    j = 0;
	if (size == 0)
		return("");
	len = len_(size, strs);
	len_s = ft_strlen(sep);
	if (malloc(len + 1 + (size - 1) * len_s) == NULL)
		return ("");
	ptr = malloc(len + 1 + (size - 1) * len_s);
	while (i < size)
	{
		while (strs[i][j])
		{
			*ptr = strs[i][j];
			ptr++;
			j++;
		}
		j = 0;
		i++;
	}
	return (ptr);
}


int main(void)
{
    int res;
    char arr1[2][10] = {"abcdefgthg", "pingftrhfp"};
    char sep[2] = "//";
    
    res = ft_strjoin(10, arr1, sep);
    return (0);
}
