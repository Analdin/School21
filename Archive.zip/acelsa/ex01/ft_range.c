/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: acelsa <acelsa@student.21-school.>         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/24 15:17:08 by acelsa            #+#    #+#             */
/*   Updated: 2020/09/25 19:32:24 by acelsa           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	*ft_range(int min, int max)
{
	int	*m;
	int	i;

	i = 0;
	if ((min - max) <= 0)
		return (0);
	m = malloc((max - min) + 2);
	while ((m[i] != '\0')
	{
		m[i] = min;
		min++;
		i++;
	}
	return (m);
}
