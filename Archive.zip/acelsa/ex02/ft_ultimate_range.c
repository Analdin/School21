/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: acelsa <acelsa@student.21-school.>         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/25 19:13:41 by acelsa            #+#    #+#             */
/*   Updated: 2020/09/25 20:51:53 by acelsa           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int		ft_ultimate_range(int **range, int min, int max)
{
	int	i;
	int	*q;

	i = 0;
	if ((min >= max) || (**range == '\0'))
		return (0);
	while (**range < min)
		++range;
	q = (int *)malloc(max - min + 2);
	if (q == 0)
		return (-1);
	while (*q < max)
	{
		i++;
		++q;
	}
	return (i);
}
