/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: acelsa <acelsa@student.21-school.>         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/24 14:25:25 by acelsa            #+#    #+#             */
/*   Updated: 2020/09/25 19:29:47 by acelsa           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_H

#define FT_H

#include <stdlib.h>
#include <stdio.h>

char	*ft_strdup(char *src)
{
	char	*c;
	int		i;
	int		q;

	q = 0;
	i = 0;
	while (src[i] != '\0')
		i++;
	c = malloc(i + 1);
	if (c == 0)
		return (0);
	while (src[q] != '\0')
	{
		c[q] = src[q];
		q++;
	}
	return (c);
}

int main(void)
{
    char *res;
    res = ft_strdup("abcdefgt");
    printf("%s", res);
    return (0);
}
