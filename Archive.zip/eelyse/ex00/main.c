/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eelyse <eelyse@studen.21-school.r>         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/09/29 13:09:19 by eelyse            #+#    #+#             */
/*   Updated: 2020/09/30 12:03:09 by hspengle         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <fcntl.h>

void	ft_putstr(char *str);

void	ft_putstr(char *str)
{
	int i;

	i = 0;
	while (str[i] != '\0')
	{
		write(2, &str[i], 1);
		i++;
	}
}

int		main(int argc, char *argv[])
{
	int		fd;
	int		rd;
	char	c;

	if (argc > 2)
		ft_putstr("Too many arguments.\n");
	else if (argc == 1)
		ft_putstr("File name missing.\n");
	else
	{
		fd = open(argv[1], O_RDONLY, 0);
		if (fd == -1)
			ft_putstr("Cannot read file.\n");
		rd = read(fd, &c, 1);
		while (rd)
		{
			write(1, &c, 1);
			rd = read(fd, &c, 1);
		}
		close(fd);
	}
	return (0);
}
